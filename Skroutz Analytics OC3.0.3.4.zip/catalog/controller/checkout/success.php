<?php
class ControllerCheckoutSuccess extends Controller {
	public function index() {
		$this->load->language('checkout/success');

// SKROUTZ ANALYTICS by Nicolas Lagios - NicolasLagios.com | S T A R T

    //-------------------------addOrder Action Start----------------------------
    
    $id_paraggelias = $this->session->data['order_id'];
	$metaforika_paraggelias = $this->session->data['shipping_method']['cost'];
    $synolo_paraggelias = $this->cart->getTotal()+($metaforika_paraggelias*1.24); // <- ΣΒΗΣΤΕ ΕΔΩ ΤΟ *1.24 ΑΝ ΤΑ ΜΕΤΑΦΟΡΙΚΑ ΣΑΣ ΕΙΝΑΙ ΚΑΤΑΧΩΡΗΜΕΝΑ ΜΕ ΤΟ ΦΠΑ
	$fpa_paraggelias = ($synolo_paraggelias/1.24)*0.24;
    $methodos_plhrwmhs = $this->session->data['payment_method']['title'];
	$methodos_plhrwmhs_perigrafh = "Επιλέξατε: ".$methodos_plhrwmhs." ως μέθοδο πληρωμής";
    
	$order = array(
	  'order_id'      => $id_paraggelias,
	  'revenue'       => round($synolo_paraggelias,2),
	  'shipping'      => $metaforika_paraggelias,
	  'tax'           => round($fpa_paraggelias,2),
	  'paid_by'       => $methodos_plhrwmhs,
	  'paid_by_descr' => $methodos_plhrwmhs_perigrafh
	);
    
    function addOrderAction(&$order) {
  		$order_data = json_encode($order);
  		return "skroutz_analytics('ecommerce', 'addOrder', $order_data);";
	}
    //-------------------------addOrder Action End----------------------------
    
    //-------------------------addItem Action Start----------------------------
    
   $proionta = $this->cart->getProducts();
   $item = array();
   foreach ($proionta as $proion) {
    	$proion = array(
  			'order_id'   => $this->session->data['order_id'],
  			'product_id' => $proion['product_id'],
  			'name'       => $proion['name'],
  			'price'      => $proion['price'],
  			'quantity'   => $proion['quantity']
		);
   		$item[]=$proion;
    }

    function addItemAction(&$order, &$item) {
		$item_data = json_encode(array(
		'order_id'    => $order['order_id'],
		'product_id'  => $item['product_id'],
		'name'        => $item['name'],
		'price'       => $item['price'],
		'quantity'    => $item['quantity']
  	));
		return "skroutz_analytics('ecommerce', 'addItem', $item_data);";
	}
    //-------------------------addItem Action End----------------------------
    
    //-------------------------Report Ecommerce data Start----------------------------
    	function skroutz_teliko($item,$order){
        	$st1 = "<script>";
        	$st2 = addOrderAction($order);
        	$st3a = '';
				foreach($item as &$items){
				    $st3a .= addItemAction($order,$items).',';
				}
        	$st3b = '';
        		foreach($item as &$items){
				    $st3b .= addItemAction($order,$items);
				}
        	$st4 = "</script>\n";
        	
        	if (count(array($st3a)) === 1) {
			    return $st1.$st2.$st3b.$st4; //call of the function in line 129
			}else {
            	return $st1.$st2.$st3a.$st4; //call of the function in line 129
            }
        }
    //-------------------------Report Ecommerce data End----------------------------
    
// SKROUTZ ANALYTICS by Nicolas Lagios - NicolasLagios.com | E N D
    
		if (isset($this->session->data['order_id'])) {
			$this->cart->clear();

			unset($this->session->data['shipping_method']);
			unset($this->session->data['shipping_methods']);
			unset($this->session->data['payment_method']);
			unset($this->session->data['payment_methods']);
			unset($this->session->data['guest']);
			unset($this->session->data['comment']);
			unset($this->session->data['order_id']);
			unset($this->session->data['coupon']);
			unset($this->session->data['reward']);
			unset($this->session->data['voucher']);
			unset($this->session->data['vouchers']);
			unset($this->session->data['totals']);
		}

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_basket'),
			'href' => $this->url->link('checkout/cart')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_checkout'),
			'href' => $this->url->link('checkout/checkout', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_success'),
			'href' => $this->url->link('checkout/success')
		);

		if ($this->customer->isLogged()) {
			$data['text_message'] = sprintf($this->language->get('text_customer'), $this->url->link('account/account', '', true), $this->url->link('account/order', '', true), $this->url->link('account/download', '', true), $this->url->link('information/contact'));
		} else {
			$data['text_message'] = sprintf($this->language->get('text_guest'), $this->url->link('information/contact'));
		}

		$data['continue'] = $this->url->link('common/home');

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
    	$data['footer'] = skroutz_teliko($item,$order).$this->load->controller('common/footer'); //Skroutz Analytics Fix edited line
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('common/success', $data));
	}
}